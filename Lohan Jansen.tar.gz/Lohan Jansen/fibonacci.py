# -*- coding: utf-8 -*-
"""
Created on Fri Feb 13 13:51:06 2023

@author: Lohan Jansen
"""

import argparse
import numpy as np

def find_fibonacci_index(n):

    """
    This function finds the index of the first term in the Fibonacci sequence
    to contain N digits, where N is passed in as an argument.
    """
    # Initialize the index and the array to store the Fibonacci terms
    index = 3
    fib = np.array([1, 1])

    # Keep looping until the length of the last term is equal to or greater than n
    while True:

        # Append the next term in the sequence to the fib array
        fib = np.append(fib, fib[-1] + fib[-2])

        # Check if the length of the last term is equal to or greater than n
        if len(str(fib[-1])) >= n:

            # If the length is equal to or greater than n, return the index + 1 to indicate the numerical position of n 
            return index

        # If the length is not equal to or greater than n, increment the index
        index += 1

if __name__ == '__main__':
    
    # create an ArgumentParser object
    parser = argparse.ArgumentParser(description='Find the index of the first Fibonacci term with N digits.')

    # add an argument for the number of digits
    parser.add_argument('n', type=int, help='number of digits in the Fibonacci term')

    # parse the command-line arguments
    args = parser.parse_args()

    # find the index of the first term in the Fibonacci sequence with N digits
    result = find_fibonacci_index(args.n)

    # print the result
    print(result)
